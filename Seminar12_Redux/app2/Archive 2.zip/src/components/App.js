import NoteList from "./NoteList"
function App()
{
    return (
        <div>
            <NoteList/>
        </div>
    )
}
export default App;