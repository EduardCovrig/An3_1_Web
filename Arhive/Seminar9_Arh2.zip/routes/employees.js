const Employee=require("../models/employee");

const router=require("express").Router();


const checkNameMiddleware= (req,res,next) =>
    {
        if(req.body.lastName.length>=3 && req.body.lastName.length <=10)
            next();
        else res.status(400).json({error: "Last Name not valid"});
    }


router.route("/employees")
.get(async (req,res) => {
    try{
        const employees=await Employee.findAll();
        return res.status(200).json(employees);
    }
    catch(err) {
        return res.status(500).json(err);
    }
})
.post(checkNameMiddleware,async (req,res) =>
{
    try 
    {
        const newEmployee=await Employee.create(req.body);
        return res.status(200).json(newEmployee);
    }
    catch(err)
    {
        return res.status(500).json({ message: "Server error", error: err.message });
    }
});

module.exports=router;